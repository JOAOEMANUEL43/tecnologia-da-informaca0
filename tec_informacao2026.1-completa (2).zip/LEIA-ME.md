# Inovação tecnológica no Brasil — PINTEC 2017

Página interativa em português com dados oficiais do IBGE obtidos via [API SIDRA](https://servicodados.ibge.gov.br/api/docs/agregados?versao=3).

## Dados e fonte
- Pesquisa: **PINTEC 2017** (triênio 2015–2017). É a última edição disponível na API SIDRA v3 neste momento.
- Tabelas utilizadas: 5453, 5018, 5464, 5458, 5618, 5643, 5921, 5924, 5926, 5927, 5928.
- Os valores exibidos correspondem ao escopo da PINTEC (indústria, energia e serviços selecionados, com 10 ou mais pessoas ocupadas).

## Estrutura
```
inovacao-tecnologica-brasil/
├── index.html        # Página principal
├── css/estilo.css    # Estilos, temas claro/escuro e responsividade
├── js/
│   ├── api.js        # Cliente da API SIDRA (atualização ao vivo)
│   ├── app.js        # Lógica da página, interações e renderização
│   └── charts.js     # Gráficos SVG/HTML puros (sem bibliotecas)
└── dados/
    ├── snapshot.js   # Snapshot local (fallback)
    └── coletar.ps1   # Script para gerar snapshot a partir da API SIDRA
```

## Pré-visualização local
O projeto é estático. Para evitar bloqueios de CORS ao abrir `file://`, utilize um servidor HTTP local.

No PowerShell (Windows):
```powershell
# A partir da raiz do projeto
.\inovacao-tecnologica-brasil\..\servir.ps1
# ou
powershell -ExecutionPolicy Bypass -File "C:\Users\jeonb\AppData\Local\Temp\opencode\servir.ps1" -Raiz "C:\Users\jeonb\Downloads\tec_informacao2022.1\inovacao-tecnologica-brasil" -Porta 8765
```

Depois abra [http://localhost:8765/](http://localhost:8765/).

## Gerar snapshot a partir da API SIDRA
O script `dados/coletar.ps1` consulta todas as 12 tabelas em paralelo e salva `dados/snapshot.js` no formato `window.SIDRA_SNAPSHOT = {...}`.

**Importante (PowerShell 5.1):** salvar o arquivo com **UTF-8 com BOM** para que acentos sejam lidos corretamente. Também evite travessões (—) dentro de strings aspas-duplas no PowerShell.

Para executar:
```powershell
cd "C:\Users\jeonb\Downloads\tec_informacao2022.1\inovacao-tecnologica-brasil\dados"
powershell -ExecutionPolicy Bypass -File .\coletar.ps1
```

O snapshot já existente foi gerado com sucesso e a página utiliza-o como fallback caso a API esteja indisponível.

## Funcionalidades
- Medidores de inovação (produto/processo e sentido amplo)
- Evolução histórica 2008–2017 com abas (taxas, gastos, intensidade)
- Ranking de setores por taxa de inovação com filtros por grupo
- Tipos de inovação, grau de novidade e participação nas vendas
- Dispêndios em inovação por atividade
- Ecossistema: fontes de informação, cooperação e apoio do governo
- Obstáculos à inovação (inovadoras x não inovadoras)
- Inovação organizacional/marketing e biotecnologia/nanotecnologia
- Tabela pesquisável, ordenável e com exportação CSV
- Atualização ao vivo via API SIDRA com indicador de status
- Tema claro/escuro com persistência
- Design responsivo e impressão amigável

## Observações
- A API SIDRA é CORS-enabled; a atualização ao vivo funciona quando servido por HTTP.
- Valores monetários são apresentados em milhares de reais conforme publicados pelo SIDRA (convertidos para R$ milhões/ bilhões na interface).
- Alguns setores com base pequena são sinalizados na interface.
- Os dados não são deflacionados.
